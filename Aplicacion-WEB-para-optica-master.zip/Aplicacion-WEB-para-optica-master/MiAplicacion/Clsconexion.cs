﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MiAplicacion

{
    public class Clsconexion
    {
        protected SqlDataReader reader;
        protected SqlDataAdapter AdaptadorDatos;
        protected DataSet data;
        protected SqlConnection oconexion = new SqlConnection();

        public Clsconexion()
        {

        }
        public void conectar(string tabla)
        {
            string strConeccion = ConfigurationManager.ConnectionStrings["clientesConnectionString"].ConnectionString;
            oconexion.ConnectionString = strConeccion;
            oconexion.Open();
            AdaptadorDatos = new SqlDataAdapter("select * from " + tabla, oconexion);
            SqlCommandBuilder ejecutacomandos = new SqlCommandBuilder(AdaptadorDatos);
            Data = new DataSet();

            AdaptadorDatos.Fill(Data, tabla);
            oconexion.Close();  
        }

        public DataSet Data{
            set { data = value; }   
            get { return data; }    
        }
        public SqlDataReader DataReader{
            set { reader = value; }
            get { return  reader; }
        }
    }

    
}